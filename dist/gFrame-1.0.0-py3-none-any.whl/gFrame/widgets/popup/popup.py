from ...baseImporter import pygame, vars
from ...core.draw import Draw
from ...core.interactions import Interactions

class PopUp:
    def __init__(self, width: vars.validScreenUnit, height: vars.validScreenUnit, ) -> None:
        pass
    
# in progress