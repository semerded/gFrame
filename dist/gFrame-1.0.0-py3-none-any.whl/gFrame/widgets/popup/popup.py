from ...baseImporter import pygame, vars
from ...components.draw import Draw
from ...components.interactions import Interactions

class PopUp:
    def __init__(self, width: vars.validScreenUnit, height: vars.validScreenUnit, ) -> None:
        pass
    
# in progress