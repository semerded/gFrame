class Animate:
    def __init__(self) -> None:
        pass
    
    def moveTo(startCords, endCords, timeInMs):
        pass