class shareKey:
    def getShareKey():
        pass
    
    