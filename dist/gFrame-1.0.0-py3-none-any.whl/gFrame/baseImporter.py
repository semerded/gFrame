try:
    import pygame
except ImportError:
    raise ImportError("install pygame with 'pip install pygame' to use this library")
from . import vars
