try:
    import pygame
except baseImporterror:
    raise baseImporterror("install pygame with 'pip install pygame' to use this library")
